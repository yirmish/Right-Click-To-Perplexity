
export const PERPLEXITY_SEARCH_URL = 'https://www.perplexity.ai/search?q=';
