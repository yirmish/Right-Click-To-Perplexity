
import { GoogleGenAI } from "@google/genai";

// Ensure the API key is available, as per the environment setup.
if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Refines a user's search query using the Gemini API for conciseness and effectiveness.
 * @param query The raw user query.
 * @returns A promise that resolves to the refined query string.
 */
export const refineQueryWithGemini = async (query: string): Promise<string> => {
  if (!query.trim()) {
    throw new Error("Query cannot be empty.");
  }

  const prompt = `
    You are an expert search query assistant. Your task is to take a user's raw text or question and refine it into a concise, effective search query suitable for a powerful AI search engine like Perplexity.
    - Focus on core keywords.
    - Remove conversational fluff and filler words.
    - Clarify ambiguity and rephrase for better search intent.
    - Return ONLY the refined search query and nothing else. Do not add any preamble, explanation, or quotation marks around the result.

    Original query: "${query}"
  `;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          temperature: 0.3,
          topP: 0.9,
          topK: 32,
        }
    });

    const refinedText = response.text.trim();

    if (!refinedText) {
        throw new Error("Gemini returned an empty response. Try rephrasing your query.");
    }
    
    return refinedText;
  } catch (error) {
    console.error("Error refining query with Gemini:", error);
    // Provide a more user-friendly error message
    throw new Error("Failed to refine query with Gemini. The API may be unavailable or the request was blocked.");
  }
};
